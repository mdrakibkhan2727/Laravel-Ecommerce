<?php if(Session('success')): ?>
<div class="alert bg-primary fade in">
	<a href="#" class="close" data-dismiss="alert">×</a>
	<?php echo e(Session('success')); ?>

</div>
<?php endif; ?>

<?php if($errors->any()): ?>
	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="alert bg-danger fade in">
		<a href="#" class="close" data-dismiss="alert">×</a>
		<?php echo e($error); ?>

	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php /**PATH E:\xampp\htdocs\flipmart\resources\views/includes/message.blade.php ENDPATH**/ ?>