@extends('layouts.website')

@section('content')
    <h1>Product</h1>
@endsection
